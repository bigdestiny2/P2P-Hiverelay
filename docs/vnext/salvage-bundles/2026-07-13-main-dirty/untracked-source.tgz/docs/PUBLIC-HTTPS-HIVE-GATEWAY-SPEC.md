# Public HTTPS Hive Gateway Specification

Status: **design draft; implementation deferred**

This document specifies browser-compatible HTTPS access to public HiveRelay
applications without making one company, domain, gateway, directory, or TLS
key the identity of the application.

Runtime implementation is intentionally deferred until the blind-substrate
update and its role boundaries are stable. This document may evolve with that
work; it does not authorize changes to live relay, custody, fleet, DNS, or
certificate surfaces.

## 1. Design objective

Provide ordinary browsers with URLs for public P2P applications while keeping
the following HiveRelay property:

> The application key is canonical. Every HTTPS name and gateway is a
> replaceable compatibility entrance.

The desired address forms are:

```text
hive://<app-key>/<path>                                  canonical P2P identity
https://<z32-app-key>.hive.<gateway-domain>/<path>       gateway-specific HTTPS
https://app.publisher.example/<path>                     publisher-owned HTTPS
```

The provisional `hive:` spelling is not frozen by this spec. The ecosystem may
retain `hyper:`, use a Pear-native scheme, or register another scheme later.
The HTTPS design depends only on a canonical 32-byte app/drive key.

## 2. Non-goals

This design does not create:

- a mandatory global `hive` domain or central control plane;
- a global account database required to publish or resolve an app;
- public HTTP access to blind, local-first, custody, shard, or private data;
- one wildcard TLS private key shared across independent relay operators;
- a trusted central gateway selector or load balancer;
- an arbitrary TCP/UDP or local-network proxy (Holesail owns that function);
- a claim that ordinary browser HTTPS verifies Hypercore provenance;
- default request/response body capture;
- gateway-side mutation of bytes in verifiable serving mode; or
- gateway, DNS, OAuth, or Web-PKI identity as a replacement for P2P identity.

## 3. Placement in the blind-substrate architecture

The blind-substrate split is a security boundary, not a deployment preset.

| Role | Storage/exposure purpose | HTTPS gateway relationship |
| --- | --- | --- |
| T1 availability relay | Public application availability, retrieval proof, circuit transport | MAY run the public HTTPS gateway as a layer-2/distribution component |
| T2 custody vault | Blind, time-bounded custody; no public content announcement or gateway | MUST NOT mount app-hosting routes, advertise gateway names, terminate app HTTPS, or participate in public gateway discovery |
| T3 witness | Independent observation and signed witness statements | MUST NOT serve app content; MAY verify gateway or expiry evidence as a client |

The RelayKernel-compatible core remains responsible for seeding, retrieval
proofs, circuits, signed metadata, and accounting. Host routing, DNS bindings,
TLS, HTTP policy, and browser response shaping live in a separate gateway
layer. The Blindspark appliance may package both T1 and the gateway, but the
protocol architecture must not make the gateway part of T2.

### 3.1 Fail-closed tier rule

The gateway serves an app only when all of the following are true:

1. the resolved app key is valid and canonical;
2. the local registry has a seeded entry for that exact key;
3. the entry is explicitly `public` and T1/availability-class;
4. the entry is not blind, custody, temporary, atomic-handoff, or shard data;
5. the publisher policy permits HTTP code/content serving;
6. any custom-domain lease is valid for the app, gateway, domain, and time; and
7. the requested version/fork constraints, when present, match local state.

Missing, unknown, transitional, or contradictory tier metadata is rejected.
There is no compatibility fallback from an unknown tier to `public`.

## 4. Trust model

### 4.1 What HTTPS proves

For an ordinary browser, Web PKI proves that the responding server is
authorized for the DNS name. It does not prove that the server returned the
expected Hyperdrive bytes, current fork, or publisher-approved policy.

Consequently:

- native HiveRelay/Pear clients verify Hypercore data directly;
- proof-aware clients may verify proof-carrying HTTP responses;
- a browser extension or previously trusted loader may verify signed bundles;
- an unmodified browser on first visit still trusts its HTTPS origin; and
- publisher-owned domains explicitly authorize their selected web gateways.

The system must describe this distinction honestly. `httpsVerified` and
`contentVerified` are separate verdicts.

### 4.2 Gateway capabilities and limits

A public gateway can observe the browser IP, hostname, path, timing, and public
response bytes. It can censor, delay, replay stale content, or return incorrect
bytes to a client that does not verify provenance. It cannot forge a valid
publisher signature, Hypercore proof, or gateway lease.

Private data therefore stays on native encrypted P2P paths. HTTPS is a T1
public-distribution surface, not a privacy upgrade.

### 4.3 Replaceability

The same app key may be served by unrelated gateway operators. Removing one
gateway changes reachability through that operator's domain, not the canonical
app identity. Publisher domains may rotate their authorized gateway set
without republishing the app.

## 5. URL and origin model

### 5.1 Gateway subdomain form

The primary gateway form is:

```text
https://<z32-app-key>.hive.<gateway-domain>/<path>
```

Requirements:

- the 32-byte app key is encoded using one frozen, lowercase z-base-32 profile;
- decoding must produce exactly 32 bytes and canonical re-encoding must match;
- the app key occupies one DNS label (52 z-base-32 characters);
- every app receives a distinct browser origin;
- the gateway rejects unknown sibling labels and malformed Host values;
- ports, trailing dots, Unicode confusables, duplicate separators, and
  proxy-forwarded host values are normalized under one tested algorithm; and
- forwarded host headers are trusted only from explicitly configured proxies.

A wildcard certificate is scoped to one operator's domain, for example
`*.hive.relay-a.example`. Independent operators never share that private key.

This model follows the origin-isolating subdomain gateway pattern used by
IPFS, while retaining Hyperdrive keys and HiveRelay proofs.

### 5.2 Existing path form

The compatibility route remains:

```text
GET /v1/hyper/:appKey/*path
```

It is useful for APIs and existing PearBrowser consumers but must not be the
preferred application-hosting form because all apps share the gateway origin.
Path mode may retain compatibility byte rewriting. It must advertise that the
response is transformed and therefore is not exact-byte/verifiable mode.

### 5.3 Publisher-owned domain form

A publisher may bind a normal domain to an app key:

```text
https://app.publisher.example/
```

The minimum binding is a DNS TXT record:

```dns
_hive.app.publisher.example. TXT \
  "v=hr1;key=<z32-app-key>;policy=<hex-policy-hash>"
```

Hive-aware clients validate the record and the corresponding publisher-signed
binding. Ordinary browsers use normal DNS and Web PKI and do not interpret the
TXT record.

Publishers may use A/AAAA records, CNAME, or HTTPS/SVCB service bindings to
direct the hostname to one or more authorized gateway operators. Each gateway
must present a certificate valid for the publisher hostname.

### 5.4 Canonical links

Gateway responses should expose both identities:

```http
Link: <hive://<app-key>/<path>>; rel="canonical"
Link: </.well-known/hiverelay-app.json>; rel="describedby"
```

HTML applications may additionally include a canonical link, but correctness
cannot depend on publishers remembering to add one.

## 6. Exact-byte public serving

Subdomain mode exists partly to remove the current need to rewrite absolute
HTML asset paths. In exact-byte mode:

- HTML, JavaScript, CSS, WASM, and other files are returned exactly as stored;
- absolute `/assets/...` paths naturally stay inside the app-specific origin;
- no HTML injection, base-tag insertion, path replacement, or script wrapping
  is permitted;
- range responses refer to the original stored bytes;
- content encoding must not change the represented payload unless the proof
  contract explicitly covers decoding; and
- errors and directory listings are gateway-generated documents and clearly
  marked as such.

Suggested response metadata:

```http
X-Hive-App-Key: <hex-app-key>
X-Hive-Gateway-Key: <hex-gateway-key>
X-Hive-Drive-Fork: <uint>
X-Hive-Drive-Length: <uint>
X-Hive-Byte-Mode: exact
ETag: "hr1-<app-key-prefix>-<fork>-<length>-<path-digest>"
```

Headers are informative until verified through a signed envelope. They must
not be described as cryptographic proof by themselves.

## 7. Signed contracts

Every JSON contract below uses deterministic canonicalization, explicit
versioning, field allowlists, bounded strings/arrays, and a domain-separated
signature. Unknown fields are rejected for the signed version.

### 7.1 Gateway advertisement

A gateway operator advertises a replaceable public entrance:

```json
{
  "type": "hiverelay-gateway-advertisement-v1",
  "relayPubkey": "<hex>",
  "gatewayPubkey": "<hex>",
  "baseDomain": "hive.relay-a.example",
  "urlTemplate": "https://{z32AppKey}.hive.relay-a.example/",
  "modes": ["subdomain-exact-v1", "path-compat-v1"],
  "privacyTiers": ["public"],
  "region": "<bounded-label>",
  "operator": "<bounded-operator-id>",
  "issuedAt": 0,
  "expiresAt": 0,
  "signature": "<hex>"
}
```

The relay identity delegates to a role-separated gateway key. The gateway key
must not reuse raw signing material from relay, custody, witness, payment, or
publisher roles. The delegation and advertisement use different signature
domains.

Advertisements may travel through signed T1 directories, publisher manifests,
direct DHT metadata, or manual configuration. No single directory is required.

### 7.2 Publisher domain binding

```json
{
  "type": "hiverelay-domain-binding-v1",
  "domain": "app.publisher.example",
  "appKey": "<hex>",
  "policyHash": "<hex>",
  "issuedAt": 0,
  "expiresAt": 0,
  "publisherPubkey": "<hex>",
  "signature": "<hex>"
}
```

The binding proves publisher intent. DNS proves control of the web name. A
gateway requires both when serving a custom hostname.

### 7.3 Gateway lease

```json
{
  "type": "hiverelay-gateway-lease-v1",
  "domain": "app.publisher.example",
  "appKey": "<hex>",
  "gatewayPubkey": "<hex>",
  "policyHash": "<hex>",
  "certificateSpkiHash": "<optional-hex>",
  "notBefore": 0,
  "expiresAt": 0,
  "publisherPubkey": "<hex>",
  "signature": "<hex>"
}
```

The lease authorizes one gateway key, not an operator name or arbitrary fleet.
It may bind the intended TLS SPKI so a certificate request cannot silently
substitute another key. A gateway may enforce stricter local policy but may not
weaken the publisher policy named by `policyHash`.

### 7.4 Public gateway policy

The first policy version is deliberately small and declarative:

```yaml
version: hiverelay-public-gateway-policy-v1
privacyTier: public
byteMode: exact
methods: [GET, HEAD]
maxRequestHeaderBytes: 16384
maxResponseBytes: null
cors: same-origin
securityHeaders: strict
cache:
  mutableMaxAge: 60
  immutableMaxAge: 31536000
rateLimit:
  capacity: 120
  windowSeconds: 60
```

V1 does not contain arbitrary expressions, embedded JavaScript, external HTTP
callbacks, dynamic upstream URLs, OAuth secrets, or response-body transforms.
Later policy actions require separate threat review.

## 8. Discovery and gateway selection

Resolution starts from one or more trust roots supplied by the caller:

- the canonical app key;
- a publisher-signed app manifest;
- a publisher-owned DNS binding;
- a manually configured gateway/operator set; or
- an opt-in signed T1 directory.

A resolver:

1. validates advertisements, bindings, leases, freshness, and role domains;
2. fetches signed relay capabilities;
3. requires the public gateway feature/profile;
4. verifies the relay claims to seed the requested app;
5. obtains a fresh anchor or retrievability proof when the requested assurance
   level requires it;
6. excludes incompatible privacy, policy, fork, or version states;
7. ranks by independent operator, region, health, latency, capacity, and cost;
8. returns multiple candidates and its evidence, not one opaque "best" URL.

DNS round-robin alone is availability routing, not evidence-based selection.
Hive-aware clients should select and fail over themselves. Ordinary browsers
may use DNS multi-answer/HTTPS records and accept weaker selection semantics.

## 9. Proof-carrying HTTP profile

Exact-byte mode prepares for a trustless retrieval profile:

```http
Accept: application/vnd.hiverelay.proof+binary;version=1
```

The response envelope should bind:

- app/drive key;
- drive fork and signed length;
- file path and entry metadata;
- returned byte range;
- underlying blob/core block indices;
- Hypercore Merkle proof material;
- request nonce when relay attribution/freshness is required;
- gateway and relay identities; and
- the exact response-byte digest.

The verifier produces separate verdicts:

```json
{
  "httpsVerified": true,
  "contentVerified": true,
  "relayAttributed": true,
  "freshnessVerified": true,
  "limitation": null
}
```

The first implementation targets the HiveRelay SDK, verifier package,
PearBrowser, CLI, and browser extensions. It must not claim that a vanilla
browser automatically verifies this envelope.

## 10. TLS and certificate operation

### 10.1 Operator domain

Each gateway operator obtains and rotates its own wildcard certificate for its
own base domain. The operator may terminate TLS in nginx, Caddy, another
reviewed proxy, or a future dedicated gateway process. HiveRelay receives a
validated host only through a configured trusted-proxy boundary.

### 10.2 Publisher domain

Each authorized gateway generates its own TLS private key and obtains an exact
certificate for the publisher hostname. Certificates and keys are never copied
between unrelated gateway operators.

Initial support is manual. Automated ACME support follows only after gateway
leases and challenge authorization have conformance vectors.

Potential automation:

- HTTP-01 challenge tokens replicated to every active endpoint only under a
  valid publisher lease and bounded ACME order;
- DNS-01 through a narrowly delegated `_acme-challenge` zone;
- short-lived leases and certificates;
- optional SPKI binding in the gateway lease; and
- certificate-transparency monitoring as operator telemetry.

DNS and Web PKI remain compatibility infrastructure controlled by the domain
owner and browser trust stores. This is acceptable because they are not the
canonical P2P identity and no particular HiveRelay domain is mandatory.

## 11. Privacy-preserving traffic policy and observability

The useful ngrok idea is a programmable edge; the centralized capture and
control plane are not required.

Adoptable features:

- bounded method/path admission;
- per-app, peer/capability, or IP rate limits;
- strict security headers and same-origin defaults;
- static redirects and URL rewrites that do not alter stored response bytes;
- webhook signature verification into a signed Hypercore outbox;
- circuit breaking based on local health/proof evidence;
- local metrics and publisher-encrypted event export; and
- explicit, temporary developer capture for public applications.

Observability defaults:

- metadata only;
- bounded cardinality and retention;
- authorization/cookie/query-value redaction;
- no per-shard, custody ID, private key, capability, or tunnel-key labels;
- no body capture for non-public tiers under any flag;
- no global log collector required; and
- request replay disabled by default and limited to explicitly captured public
  requests, with safe methods preferred.

## 12. Integration map

| Existing component | Deferred integration |
| --- | --- |
| `packages/core/gateway/hyper-gateway.js` | Split path parsing from content serving; add exact-byte serve primitive and host-resolved app context |
| `packages/core/core/relay-node/gateway-server.js` | Mount host routing only for T1/public profile; keep management routes outside app origins |
| `packages/core/gateway/server.js` | Standalone gateway profile and operator-domain configuration |
| App/seeding registry | Resolve exact public availability entry; never adapt custody/shard entries into gateway entries |
| PolicyGuard/privacy model | Replace permissive defaults with explicit public/T1 admission for new host routes |
| Capability document | Advertise gateway profile, byte modes, base domain, gateway key delegation, and limitations |
| Signed directory/meta profile | Carry bounded, expiring gateway advertisements as opt-in T1 metadata |
| Anchor/retrievability proof | Admission and ranking evidence; do not rename retrievability as replication proof |
| Client SDK | Resolve advertisements, select a diverse gateway set, construct HTTPS URLs, and verify proof envelopes |
| Verifier package | Verify gateway advertisements, bindings, leases, policies, and proof-carrying responses |
| PearBrowser | Prefer native P2P; use verified HTTPS as fast-start/fallback; isolate each app origin |
| Holesail transport | Optional reachability for relay/operator services; not the public app naming or trust layer |
| nginx/reverse-proxy packaging | TLS termination and trusted-host forwarding until a dedicated gateway terminator exists |
| Fleet/Umbrel/StartOS | Operator-domain configuration, wildcard certificate mount, smoke tests, and public-safe evidence |

### 12.1 Required internal refactor

The serving engine should accept a resolved immutable context rather than
parsing every external route itself:

```js
servePublicApp(req, res, {
  appKey,
  path,
  byteMode: 'exact',
  expectedFork: null,
  expectedLength: null,
  gatewayPolicy,
  domainBinding: null
})
```

Path compatibility, subdomain routing, and custom-domain routing become thin
adapters that validate external input and construct this context. This keeps
DNS/Host parsing out of the storage engine and makes tier enforcement common
to every route.

### 12.2 Management-plane isolation

An app hostname must never route to:

- `/api/manage/*`;
- setup/wizard endpoints;
- dashboard/operator WebSockets;
- raw service management;
- seed/unseed mutation routes;
- custody/shard routes; or
- ACME management APIs.

The gateway should use a distinct public listener where practical. If a shared
listener remains for compatibility, host routing happens before management
dispatch and app hosts receive only the public content surface plus bounded
well-known metadata.

## 13. Threat model

| Threat | Required mitigation |
| --- | --- |
| One gateway disappears | Return multiple independently operated candidates; canonical app key remains valid |
| Gateway advertises another app | Bind host key, registry key, lease, proof, and response envelope to the same app key |
| Gateway serves modified bytes | Exact-byte mode plus proof-aware client verification; do not overclaim vanilla-browser integrity |
| Gateway serves stale fork/version | Signed version constraints, freshness policy, immutable URLs, proof comparison across relays |
| Cross-app cookie/storage attack | One app key per subdomain origin; never host apps through shared path origin by default |
| HTML rewrite breaks verification | No transformations in subdomain exact-byte mode |
| Host-header/DNS-rebinding attack | Canonical Host parser, explicit base-domain allowlist, trusted-proxy configuration, no localhost auth inheritance |
| Gateway reaches management API | Separate listener or pre-dispatch host isolation; app host has read-only content routes |
| T2 data leaks through gateway | Structural role separation plus explicit T1/public registry admission; fail closed on missing tier |
| Shared wildcard key compromises fleet | Per-operator wildcard keys; per-gateway exact keys for publisher domains |
| Malicious directory controls selection | Multiple discovery sources, signed advertisements, direct proof checks, caller-visible selection evidence |
| Policy downgrade | Publisher-signed policy hash in binding and lease; gateway may only tighten |
| Central traffic surveillance | Native P2P preferred; local/encrypted logs; no required global ingress or observability service |
| Domain or CA compromise | Cannot be eliminated for vanilla HTTPS; keep key identity canonical, support multiple names/gateways, expose proof verification to aware clients |

## 14. Conformance and test plan

No compatibility claim is made without checked-in vectors and negative cases.

### 14.1 Contract vectors

- app-key z-base-32 canonical encoding and DNS label cases;
- gateway-key delegation and advertisement signatures;
- domain binding and gateway lease signatures;
- policy canonicalization and hash;
- expiry, wrong-role, wrong-domain, wrong-app, wrong-gateway, and unknown-field
  rejects;
- URL template parsing and canonical output; and
- proof-envelope binary/JSON encoding and verification.

### 14.2 Gateway unit tests

- valid subdomain maps to exact seeded public app;
- malformed or non-canonical host rejected;
- unrelated gateway base domain rejected;
- public app roots and absolute assets load without HTML rewriting;
- two app keys have distinct origins and cannot share cookies/CORS authority;
- path compatibility remains unchanged;
- unknown, local-first, p2p-only, blind, custody, temporary, shard, and T2
  entries all reject;
- app host cannot reach management, wizard, seed, custody, or service routes;
- trusted/untrusted forwarded host behavior is pinned;
- Range/HEAD/cache/error behavior remains bounded; and
- start/stop/restart drains listeners and in-flight streams.

### 14.3 Integration tests

- two unrelated gateways serve the same app key with exact identical bytes;
- one gateway fails and an aware client selects another;
- wrong bytes fail proof verification;
- stale fork/version is detected;
- publisher domain binding selects only leased gateways;
- independent TLS keys serve the same publisher domain in a test PKI;
- capability and advertisement expiry remove a candidate;
- browser origin-isolation fixture covers storage, cookies, service worker, and
  CORS boundaries; and
- blind-substrate tests assert that enabling T2 never mounts or advertises the
  gateway, including mixed-role configuration rejection where required.

### 14.4 Distribution evidence

- reverse-proxy configuration validates Host and keeps internal ports loopback;
- wildcard/operator certificate and renewal smoke;
- Umbrel/StartOS persistence and upgrade behavior;
- public artifact scanner excludes private keys, ACME account material, API
  keys, tunnel keys, publisher metadata, and captured traffic; and
- fleet smoke verifies at least two independent gateway identities before any
  multi-gateway availability claim.

## 15. Execution phases

### Phase 0: substrate readiness and spec freeze

- finish the blind-substrate update;
- freeze T1/T2/T3 role identifiers and registry/storage-class semantics;
- freeze canonical signing helpers and role-domain separation;
- confirm gateway compatibility routes remain supported;
- settle gateway package/process ownership; and
- land this spec's contract fixtures before runtime behavior.

### Phase 1: operator-domain subdomain gateway

- refactor exact-byte serving from route parsing;
- add canonical Host-to-app-key routing;
- enforce explicit T1/public admission;
- add per-app origin/security behavior;
- expose bounded app well-known metadata;
- configure external wildcard TLS; and
- preserve the existing path gateway unchanged.

Deliverable:

```text
https://<z32-app-key>.hive.<operator-domain>/
```

### Phase 2: signed discovery and client resolution

- gateway key delegation;
- expiring gateway advertisements;
- capability profile additions;
- multi-source discovery;
- proof-aware diverse selection; and
- PearBrowser/SDK fallback behavior.

### Phase 3: signed policy and custom domains

- public gateway policy v1;
- domain binding and gateway lease;
- manual publisher-domain TLS;
- DNS TXT and HTTPS/SVCB guidance; and
- independent gateway certificate/key support.

### Phase 4: proof-carrying retrieval

- exact response proof envelope;
- verifier and SDK support;
- immutable version URLs/cache behavior;
- PearBrowser/extension verification; and
- honest UI verdicts separating HTTPS, content, attribution, and freshness.

### Phase 5: ACME automation and programmable public edge

- lease-authorized HTTP-01 or delegated DNS-01 flows;
- rate limits, safe static routing/redirects, webhook verification;
- evidence-driven circuit breaking;
- privacy-preserving inspection/export; and
- conformance and fleet rollout gates.

## 16. Readiness gates

Runtime implementation starts only when all gates are satisfied:

| Gate | Requirement |
| --- | --- |
| G1 role boundary | T1/T2/T3 or successor role semantics are frozen and T2 no-gateway behavior is tested |
| G2 storage classification | Public availability entries are distinguishable from every blind/custody/shard class without heuristics |
| G3 signing foundation | Canonicalization, role-domain keys, delegation, expiry, and replay rules are stable |
| G4 gateway compatibility | Existing catalog, capability, and `/v1/hyper` consumers have passing compatibility evidence |
| G5 major update green | Blind-substrate unit/integration/conformance suites pass before gateway code is rebased onto it |
| G6 ownership | A clean implementation branch/worktree is selected so unrelated in-progress changes are preserved |
| G7 operator prerequisites | At least two operators can provide distinct domains/keys for multi-gateway integration testing |

Passing G1-G6 permits Phase 1 implementation. G7 is required before making
decentralized multi-gateway availability claims.

## 17. Open decisions

1. Is the canonical user-facing scheme `hive:`, `hyper:`, or Pear-native?
2. Does the gateway ship as `p2p-hiverelay` layer-2 code, a separate package,
   or a sidecar process?
3. Is z-base-32 the final app-key DNS encoding, and what textual prefix is used
   outside DNS?
4. Which exact registry fields constitute explicit T1/public admission after
   the blind-substrate update?
5. Does the gateway use a derived role key or a separately generated/persisted
   key delegated by relay identity?
6. What proof format maps Hyperdrive file ranges to Hypercore/Hyperblobs proof
   material without buffering large responses?
7. Are publisher domain bindings stored only in DNS/app manifests, or also in
   an optional signed T1 log?
8. Which component coordinates ACME without becoming a required certificate
   control plane?
9. What minimum independent-operator evidence is required before describing a
   hostname as decentralized or highly available?

## 18. Standards and prior art

- ACME: <https://www.rfc-editor.org/rfc/rfc8555.html>
- DNS SVCB and HTTPS records: <https://www.rfc-editor.org/rfc/rfc9460.html>
- Let's Encrypt challenge operation and delegation:
  <https://letsencrypt.org/docs/challenge-types/>
- IPFS gateway origin isolation and trustless-gateway precedent:
  <https://docs.ipfs.tech/concepts/ipfs-gateway/>
- ngrok traffic-policy phases and actions, used only as ergonomics prior art:
  <https://ngrok.com/docs/traffic-policy/how-it-works>

## 19. Decision summary

Public HTTPS Hive URLs are feasible and valuable, but they belong on the
public availability edge, not inside blind custody. The first implementation
is an operator-owned, key-derived subdomain gateway serving exact public bytes.
The long-term design adds publisher domains, independently authorized gateways,
signed policies, and proof-carrying responses without creating a mandatory
central HiveRelay domain, directory, certificate key, or traffic collector.
