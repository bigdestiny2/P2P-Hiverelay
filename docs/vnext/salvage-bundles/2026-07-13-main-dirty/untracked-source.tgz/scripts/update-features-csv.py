#!/usr/bin/env python3
"""Update FEATURES.csv with Phase 1 test results and missing features."""
import csv
import os

CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "FEATURES.csv")

FIELDS = [
    "id", "phase", "surface", "component", "feature", "user_story",
    "expected_behavior", "test_approach", "status", "errors_found",
    "file_refs", "notes"
]

updates = {
    # Dashboard UX gaps
    "F027": {"status": "Fail", "errors_found": "Wallets table <tbody id=walletsBody> is never populated; only summary text updates. Users see an empty table."},
    "F026": {"status": "Fail", "errors_found": "GET /api/v1/credits/pricing and /api/v1/credits/pricing/compare return 404; no such routes are mounted in relay-node. Payments dashboard shows empty rate card."},
    # API inconsistencies found during manual testing
    "F051": {"status": "Fail", "errors_found": "GET /api/status returns 404; the endpoint is mounted only at /status (top-level). Inconsistent with /api/* route scheme."},
    "F053": {"status": "Fail", "errors_found": "GET /api/metrics returns 404; Prometheus metrics are served only at /metrics (top-level). Inconsistent with /api/* route scheme."},
    # Example bug
    "F124": {"status": "Fail", "errors_found": "Crash: TypeError Cannot read properties of null (reading 'slice') at line 55 when app.appKey is null."},
    # Packaging caveats
    "F118": {"status": "Partial", "errors_found": "", "notes": "README mentions createBuiltInServices({enabled: [...]}) but this function is not exported from packages/services/index.js."},
}

new_rows = [
    # Missing CLI commands
    {
        "id": "F143", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "init — Initialize config + install agent skills",
        "user_story": "As a first-time operator, I want to initialize a default config and install agent skills so that I can start quickly.",
        "expected_behavior": "Creates ~/.hiverelay/config.json with defaults, optionally sets region and max-storage, installs agent skills.",
        "test_approach": "Run p2p-hiverelay init --region NA --max-storage 50GB.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F144", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "testnet — Spin up local testnet",
        "user_story": "As a developer, I want to spin up a local DHT + relays + client so that I can test without the public network.",
        "expected_behavior": "Starts N relay nodes on local DHT, optional test client, prints endpoints.",
        "test_approach": "Run p2p-hiverelay testnet --nodes 3 --no-client.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F145", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "ghostdrive — Ghost Drive pin/publish/discover workflows",
        "user_story": "As a user, I want to pin, publish, and discover Ghost Drives from the CLI.",
        "expected_behavior": "Subcommands for ghostdrive workflows integrate with distributed-drive bridge.",
        "test_approach": "Run p2p-hiverelay ghostdrive --help and exercise subcommands.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F146", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "catalog — Operator catalog control",
        "user_story": "As an operator, I want to manage catalog mode, allowlist, approvals, rejections, removals, and pending entries from the CLI.",
        "expected_behavior": "Subcommands: mode/allowlist/approve/reject/remove/pending call HTTP API.",
        "test_approach": "Run p2p-hiverelay catalog pending --port 29100.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F147", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "federation — Cross-relay federation",
        "user_story": "As an operator, I want to list, follow, mirror, unfollow, republish, and unrepublish federated relays.",
        "expected_behavior": "Subcommands call federation HTTP API endpoints.",
        "test_approach": "Run p2p-hiverelay federation list --port 29100.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F148", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "qvac — Manage qvac-backed AI models",
        "user_story": "As an operator, I want to register, remove, and list qvac-backed AI models on a running node.",
        "expected_behavior": "Subcommands call AI model management API.",
        "test_approach": "Run p2p-hiverelay qvac list --port 29100.",
        "status": "Cataloged", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Not in original catalog"
    },
    {
        "id": "F149", "phase": "1-Catalog", "surface": "CLI", "component": "cli/index.js", "feature": "doctor — Diagnose config + runtime drift",
        "user_story": "As an operator, I want to diagnose configuration and runtime drift and optionally auto-fix issues.",
        "expected_behavior": "Checks relay reachability, health, config file, and recommendations. --fix writes config.",
        "test_approach": "Run p2p-hiverelay doctor --port 29100 and doctor --fix.",
        "status": "Tested", "errors_found": "", "file_refs": "packages/core/cli/index.js", "notes": "Works; reports warnings for unset region/operator/autoHeal"
    },
    # API status/metrics aliases (new separate feature rows to capture the alias gap)
    {
        "id": "F150", "phase": "1-Catalog", "surface": "Core API", "component": "api-status-read.js", "feature": "GET /api/status alias",
        "user_story": "As an API consumer, I expect the status endpoint under /api/status because every other API route uses the /api prefix.",
        "expected_behavior": "GET /api/status returns the same payload as GET /status.",
        "test_approach": "curl /api/status and compare with /status.",
        "status": "Fail", "errors_found": "Returns 404; only /status is mounted.", "file_refs": "packages/core/core/relay-node/api-status-read.js", "notes": ""
    },
    {
        "id": "F151", "phase": "1-Catalog", "surface": "Core API", "component": "api-metrics.js", "feature": "GET /api/metrics alias",
        "user_story": "As a monitoring tool operator, I expect Prometheus metrics under /api/metrics for consistency with the rest of the API.",
        "expected_behavior": "GET /api/metrics returns the same Prometheus text as GET /metrics.",
        "test_approach": "curl /api/metrics and compare with /metrics.",
        "status": "Fail", "errors_found": "Returns 404; only /metrics is mounted.", "file_refs": "packages/core/core/relay-node/api-metrics.js", "notes": ""
    },
]

with open(CSV_PATH, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

row_map = {r["id"]: r for r in rows}

for uid, upd in updates.items():
    if uid not in row_map:
        print(f"Warning: {uid} not found")
        continue
    for k, v in upd.items():
        row_map[uid][k] = v

existing_ids = set(row_map.keys())
for nr in new_rows:
    if nr["id"] in existing_ids:
        print(f"Warning: {nr['id']} already exists, skipping")
        continue
    rows.append(nr)

with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerows(rows)

fail_count = sum(1 for r in rows if r["status"] == "Fail")
print(f"Updated {len(updates)} rows, appended {len(new_rows)} rows. Total features: {len(rows)}. Failing: {fail_count}.")
