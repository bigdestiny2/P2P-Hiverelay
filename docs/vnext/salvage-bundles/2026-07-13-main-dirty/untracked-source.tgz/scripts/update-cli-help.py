#!/usr/bin/env python3
"""Record CLI --help fix in FEATURES.csv."""
import csv
import os

CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "FEATURES.csv")

with open(CSV_PATH, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

# Find next id
max_id = max(int(r["id"][1:]) for r in rows)
new_id = f"F{max_id + 1:03d}"

new_row = {
    "id": new_id,
    "phase": "1-Catalog",
    "surface": "CLI",
    "component": "cli/index.js",
    "feature": "Global --help handling for simple commands",
    "user_story": "As a CLI user, I want --help to print usage for any command so that I don't accidentally execute init/testnet/start/setup/manage when I only wanted help.",
    "expected_behavior": "p2p-hiverelay <command> --help prints the global usage banner and exits 0 for commands without their own subcommand parser; commands with subcommand parsers (catalog, federation, qvac, ghostdrive) keep their command-specific help.",
    "test_approach": "Run each command with --help and verify it prints usage instead of executing.",
    "status": "Retested",
    "errors_found": "",
    "file_refs": "packages/core/cli/index.js:135-165",
    "notes": "Fixed by intercepting --help in main() before dispatching to commands that lack subcommand help handlers."
}

# Also add notes to affected commands
affected = {
    "F042": "--help now prints usage instead of starting interactive setup.",
    "F043": "--help now prints usage instead of starting the management TUI.",
    "F044": "--help now prints usage instead of crashing while starting a relay.",
    "F143": "--help now prints usage instead of initializing config and installing skills.",
    "F144": "--help now prints usage instead of spinning up a local testnet."
}

row_map = {r["id"]: r for r in rows}
for uid, note in affected.items():
    if uid in row_map:
        row_map[uid]["notes"] = (row_map[uid]["notes"] + " " + note).strip() if row_map[uid]["notes"] else note

rows.append(new_row)

with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print(f"Added {new_id}. Total features: {len(rows)}.")
