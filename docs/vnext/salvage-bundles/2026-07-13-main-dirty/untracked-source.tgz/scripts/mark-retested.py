#!/usr/bin/env python3
"""Mark Phase 2 fixes as retested in FEATURES.csv."""
import csv
import os

CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "FEATURES.csv")

updates = {
    "F026": {"status": "Retested", "errors_found": "", "notes": "Fixed by adding /api/v1/credits/pricing and /api/v1/credits/pricing/compare endpoints using PricingEngine defaults."},
    "F027": {"status": "Retested", "errors_found": "", "notes": "Fixed by adding /api/v1/credits/stats and /api/v1/credits/wallets endpoints and populating the wallets table in payments.html."},
    "F051": {"status": "Retested", "errors_found": "", "notes": "Fixed by accepting /api/status in addition to /status in resolveStatusRoute."},
    "F053": {"status": "Retested", "errors_found": "", "notes": "Fixed by accepting /api/metrics in addition to /metrics in resolveMetricsRoute."},
    "F118": {"status": "Retested", "errors_found": "", "notes": "Fixed README to show actual service-class import pattern and note that createBuiltInServices is not provided."},
    "F124": {"status": "Retested", "errors_found": "", "notes": "Fixed defensive appKey/source access so the example no longer crashes on null appKey."},
    "F125": {"status": "Retested", "errors_found": "", "notes": "Fixed same null appKey/source crash as node-app example."},
    "F150": {"status": "Retested", "errors_found": "", "notes": "Alias implemented and verified."},
    "F151": {"status": "Retested", "errors_found": "", "notes": "Alias implemented and verified."},
}

with open(CSV_PATH, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    rows = list(reader)

row_map = {r["id"]: r for r in rows}
for uid, upd in updates.items():
    if uid not in row_map:
        print(f"Warning: {uid} not found")
        continue
    for k, v in upd.items():
        row_map[uid][k] = v

with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)

fail_count = sum(1 for r in rows if r["status"] == "Fail")
retested_count = sum(1 for r in rows if r["status"] == "Retested")
print(f"Updated {len(updates)} rows. Failing: {fail_count}. Retested: {retested_count}.")
