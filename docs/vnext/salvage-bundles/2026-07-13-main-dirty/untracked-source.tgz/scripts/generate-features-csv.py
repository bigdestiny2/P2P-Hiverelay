#!/usr/bin/env python3
"""Generate the canonical HiveRelay feature spreadsheet."""
import csv
import os

CSV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "FEATURES.csv")

FIELDS = [
    "id", "phase", "surface", "component", "feature", "user_story",
    "expected_behavior", "test_approach", "status", "errors_found",
    "file_refs", "notes"
]

# status values: Cataloged | Tested | Pass | Fail | Fixed | Retested | Blocked | Skipped

def row(id_, phase, surface, component, feature, story, behavior, test, status="Cataloged", errors="", refs="", notes=""):
    return {
        "id": id_,
        "phase": phase,
        "surface": surface,
        "component": component,
        "feature": feature,
        "user_story": story,
        "expected_behavior": behavior,
        "test_approach": test,
        "status": status,
        "errors_found": errors,
        "file_refs": refs,
        "notes": notes,
    }

rows = []
n = 0

def nid():
    global n
    n += 1
    return f"F{n:03d}"

# ============================================================================
# DASHBOARD (dashboard/)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Node Overview Stats",
    "As a relay operator, I want to see at-a-glance metrics about my node so that I can quickly judge its health and load.",
    "Four stat cards display Connections, Apps Kept Alive, Data Stored, and Data Relayed from GET /api/overview.",
    "Load /dashboard and verify stat cards populate.",
    refs="dashboard/index.html:285-306,856-861; packages/core/core/relay-node/api-overview.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Subsidy Earnings Panel",
    "As a relay operator, I want to see my accrued subsidy earnings and set a payout destination so that I can get paid by the network.",
    "Panel hidden unless subsidy.enabled. Shows total sats, today's sats, daily cap progress, payout destination chip. Clicking destination opens dialog to save a Lightning/BOLT12/Bitcoin address via POST /api/subsidy/destination.",
    "Enable subsidy, load /dashboard, click payout chip, enter address, save.",
    refs="dashboard/index.html:309-332,1070-1137"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Connection & Traffic Charts",
    "As a relay operator, I want to visualize recent connections and traffic so that I can spot trends.",
    "Two canvas charts render the last hour of data from GET /api/history?minutes=60. Empty state until samples arrive. Redraw on resize.",
    "Load /dashboard, wait for samples, verify charts render.",
    refs="dashboard/index.html:335-352,661-769,964-999,1457-1463"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Payment & Credits Stats",
    "As a relay operator, I want to see revenue, wallets, service calls, and invoices when payments are active so that I can track monetization.",
    "Four-card row appears only when payment stack signals activity in /api/overview; otherwise hidden.",
    "Enable payments, load /dashboard, verify cards appear.",
    refs="dashboard/index.html:355-379,929-950"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Seeded Apps Table",
    "As a relay operator, I want to see which apps are seeded on my node and sort them so that I can inspect usage.",
    "Table lists Name, Developer, App Key, Started, Uptime, Bytes Served. Catalog metadata used when available; columns sortable.",
    "Seed apps, load /dashboard, sort columns.",
    refs="dashboard/index.html:382-399,798-820; packages/core/core/relay-node/api-apps-read.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "System Info Panel",
    "As a relay operator, I want to see memory, storage, circuits, and error counts so that I can diagnose resource pressure.",
    "Progress bars for heap/storage appear when totals exist. RSS shown without fabricated ratio.",
    "Load /dashboard, verify system info.",
    refs="dashboard/index.html:404-416,876-919"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Active Peers Panel",
    "As a relay operator, I want to see which peers are currently connected so that I can verify connectivity.",
    "Scrollable list of connected peer pubkeys; count badge updates live.",
    "Load /dashboard with connected peers.",
    refs="dashboard/index.html:418-424,635-647"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Registry Management",
    "As a relay operator, I want to control whether seed requests are auto-accepted and manually approve or reject pending requests so that I can curate what my node hosts.",
    "Toggle between AUTO-ACCEPT and APPROVAL MODE. Pending table with Approve/Reject. Active seeds table with UNSEED action.",
    "Switch mode, submit seed request, approve/reject, unseed app.",
    refs="dashboard/index.html:427-457,1262-1395; packages/core/core/relay-node/api-registry-status.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Header Pubkey Chip & Uptime Badge",
    "As a relay operator, I want to copy my node's public key and see uptime so that I can share identity and verify liveness.",
    "Clicking pubkey chip copies full key. Uptime badge orange if uptime < 1 min.",
    "Load /dashboard, click pubkey chip, verify clipboard.",
    refs="dashboard/index.html:278-282,599-633"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "index.html", "Live Updates",
    "As a relay operator, I want the dashboard to update automatically so that I see current state without refreshing.",
    "Uses WebSocket /ws with update messages; falls back to HTTP polling every 5s (or 30s when WS live). Connection pill shows WS LIVE / POLLING / DISCONNECTED.",
    "Load /dashboard, check connection pill, trigger change, verify update.",
    refs="dashboard/index.html:1001-1216"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "wizard.html", "Multi-Step Setup Wizard",
    "As a new relay operator, I want to step through naming my relay, setting a payout wallet, and choosing a seed policy so that my node is correctly configured.",
    "Five steps: Welcome -> Relay Name -> Payout -> Accept Mode -> Complete. Fetches /api/wizard on load; redirects to dashboard if complete unless ?edit=1.",
    "Open /wizard on fresh node, complete steps.",
    refs="dashboard/wizard.html:387-507,595-849; packages/core/core/wizard.js; packages/core/core/relay-node/api-wizard-actions.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "wizard.html", "Accept-Mode Selection",
    "As a relay operator, I want to choose between Review, Allowlist, and Open seeding policies so that I control incoming requests.",
    "Three choice cards; selecting enables Continue. Choice saved via accept-mode API.",
    "In /wizard, select each mode and continue.",
    refs="dashboard/wizard.html:454-488,694-720"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "calculator.html", "Earnings Estimator",
    "As a prospective relay operator, I want to estimate monthly revenue and profit from hosting apps and AI calls so that I can decide whether to run a node.",
    "Sliders/inputs for apps, AI calls, tokens, embeddings, storage writes, sign calls, pricing margin, BTC price, monthly costs. Outputs hero monthly earnings, daily revenue, costs, profit, P&L, ROI, annual projection.",
    "Open /calculator, adjust sliders, verify outputs update.",
    refs="dashboard/calculator.html:230-333,580-682"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "calculator.html", "Quick Presets",
    "As a user, I want to load common node profiles quickly so that I don't have to tune every slider.",
    "Five buttons (Hobby, Small, Medium, Large, Enterprise) populate inputs and recalculate.",
    "Click each preset, verify values and outputs.",
    refs="dashboard/calculator.html:178-194,446-474"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "catalog.html", "Catalog Browser",
    "As a user, I want to browse apps, drives, datasets, and media seeded across the network so that I can discover content.",
    "Loads /catalog.json, displays cards with type badges, descriptions, metadata, keys. Search and type filters. Paginates 24 items. Auto-refreshes every 30s.",
    "Open /catalog, search, filter, paginate.",
    refs="dashboard/catalog.html:154-172,207-296; packages/core/core/relay-node/api-catalog-read.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "catalog.html", "Catalog Card Actions",
    "As a user, I want to open a catalog item in the gateway or copy its key so that I can access the content.",
    "Each card has Browse Files link to /v1/hyper/{key}/ and Copy Key button with toast.",
    "Click Browse Files and Copy Key.",
    refs="dashboard/catalog.html:298-387"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "network.html", "Relay Network Explorer",
    "As a user, I want to discover and inspect relays on the HiveRelay network so that I can find nodes to connect to.",
    "Fetches /api/network and renders relay cards with online/offline, region, stats, Tor/Holesail badges. Summary cards. Filter for relays with API.",
    "Open /network, verify relay cards and summary.",
    refs="dashboard/network.html:235-272,508-818; packages/core/core/relay-node/api-network-state.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "network.html", "Connect Modal",
    "As a developer, I want to copy connection details and SDK code for a relay so that I can bootstrap a client.",
    "Click Connect opens modal with pubkey, API endpoint, sample SDK code, dashboard URL, onion address. Clicking code block copies it.",
    "Open /network, click Connect, copy code blocks.",
    refs="dashboard/network.html:277-304,450-504"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "network.html", "Live Network Updates",
    "As a user, I want the network view to update live so that I see current relay status.",
    "Uses WS /ws with update.network; falls back to HTTP polling every 10s (30s when WS live). Auto-reconnects.",
    "Open /network, check live updates.",
    refs="dashboard/network.html:647-708"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "leaderboard.html", "Reputation Leaderboard",
    "As a relay operator, I want to see how my node ranks against others so that I can benchmark performance and reliability.",
    "Fetches /api/reputation, renders sortable table with rank, pubkey, score, reliability, latency, uptime, bytes served, region, last activity. Local node highlighted with YOU badge.",
    "Open /leaderboard, verify local node badge and rankings.",
    refs="dashboard/leaderboard.html:204-249,469-592; packages/core/core/relay-node/api-reputation-read.js"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "leaderboard.html", "Leaderboard Sorting",
    "As a user, I want to sort the leaderboard by different metrics so that I can find top performers.",
    "Clicking column headers toggles ascending/descending sort and updates arrows.",
    "Click each sortable column header.",
    refs="dashboard/leaderboard.html:457-467,677-689"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "leaderboard.html", "Live Leaderboard Updates",
    "As a user, I want leaderboard data to refresh automatically so that rankings stay current.",
    "WS /ws listens for reputation/leaderboard messages; HTTP polls every 10s fallback. Connection pill shows status.",
    "Open /leaderboard, check live updates.",
    refs="dashboard/leaderboard.html:637-696"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "Payments Overview",
    "As a relay operator, I want to see total revenue, wallets, service calls, and settled invoices so that I can track payment activity.",
    "Four stat cards from /api/overview payment fields. Provider badge in header.",
    "Enable payments, open /payments, verify cards.",
    refs="dashboard/payments.html:172-193,477-521"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "Settlement Account",
    "As a relay operator, I want to see earned, paid, held, and pending payout amounts so that I can understand my settlement state.",
    "Card displays account breakdown and held-percentage progress bar.",
    "Open /payments with payment accounts configured.",
    refs="dashboard/payments.html:198-223,510-520"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "Invoice Status",
    "As a relay operator, I want to see counts of settled, pending, expired, and cancelled invoices so that I can track Lightning payments.",
    "Four status boxes plus total settled value.",
    "Open /payments with invoice history.",
    refs="dashboard/payments.html:226-250,499-506"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "Rate Card & Pricing Comparison",
    "As a developer or operator, I want to see service prices and compare them to cloud APIs so that I can evaluate cost.",
    "Renders rate card from /api/v1/credits/pricing and comparison from /api/v1/credits/pricing/compare.",
    "Open /payments, verify pricing tables.",
    refs="dashboard/payments.html:254-273,524-540,414-474"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "App Credit Wallets",
    "As a relay operator, I want to see app credit wallet balances and activity so that I can monitor credit usage.",
    "Wallet summary fetched from /api/v1/credits/stats. Table body declared but never populated with rows; only summary text updates.",
    "Open /payments, inspect wallets table.",
    refs="dashboard/payments.html:277-291,543-557",
    notes="KNOWN GAP: table rows not rendered; only summary text"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "payments.html", "Live Payments Updates",
    "As a relay operator, I want payment stats to update live so that I see new earnings.",
    "WS /ws with update.overview; HTTP polls every 10s. Wallets polled every 30s.",
    "Open /payments, trigger payment event, verify update.",
    refs="dashboard/payments.html:636-680"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Appliance Status Hero",
    "As a Blindspark appliance user, I want a simple view of my relay status, name, public key, and uptime so that I can confirm it is online.",
    "Displays relay name, truncated pubkey (click to copy), tagline, status badge (Online/Degraded/Offline). Degraded explains health-check issue.",
    "Open /dashboard in simple mode, verify hero.",
    refs="dashboard/blindspark.html:398-402,616-671"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Storage Cap Configuration",
    "As an appliance user, I want to set how much disk HiveRelay may use so that it doesn't fill my box.",
    "Number input in GB; Apply POSTs maxStorageBytes to /api/manage/config. Toast confirms.",
    "In simple mode, change storage cap, apply.",
    refs="dashboard/blindspark.html:411-421,814-824"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Accept Mode & Payout Wallet",
    "As an appliance user, I want to see my accept mode and add/change/clear a payout wallet so that I can receive earnings.",
    "Accept mode shown as badge with note. Payout address as copyable chip with Add/Change button. Dialog supports save/clear destination via POST /api/subsidy/destination.",
    "In simple mode, add/clear payout wallet.",
    refs="dashboard/blindspark.html:424-449,673-781,487-502"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Optional Service Management",
    "As an appliance user, I want to choose which service plugins my relay runs so that I can enable only needed capabilities.",
    "Checklist of available services with live/pending/stopping/draft states. Save selection stores config; Restart now applies changes. AI model form when AI active.",
    "In simple mode, toggle services, save, restart.",
    refs="dashboard/blindspark.html:453-456,837-999,1214-1441"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Verified Usage Meter",
    "As an appliance user, I want to see verified signed usage and poker usage so that I can understand payout-eligible activity.",
    "If services enabled, fetches /api/usage and optionally /api/poker/usage, renders signed receipt counts and totals.",
    "Enable services, open simple dashboard, verify meter.",
    refs="dashboard/blindspark.html:1443-1472"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Paid Seeding Lease Config",
    "As an appliance user, I want to set a per-GiB/day rate for paid seeding and see lease earnings so that I can monetize storage.",
    "Row hidden unless lease.enabled. Input sets satsPerGiBDay; displays active leases, paid lease count, total sats earned.",
    "Enable lease, set rate, verify display.",
    refs="dashboard/blindspark.html:436-439,1484-1522"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Hosted Apps & Manual Seeding",
    "As an appliance user, I want to see apps held by my relay and manually seed a new app by drive key so that I can host specific content.",
    "List of hosted apps. + Seed an app toggles form validating 64-char hex key, optional name, POSTs to /seed.",
    "In simple mode, seed a valid and invalid key.",
    refs="dashboard/blindspark.html:458-480,1524-1625"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "PearBrowser Subscribe URL",
    "As an appliance user, I want to copy my relay's base URL so that I can add it to PearBrowser.",
    "Button displays origin hostname; click copies full URL to clipboard with toast.",
    "Click subscribe URL button, verify clipboard.",
    refs="dashboard/blindspark.html:444-450,1628-1637"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "blindspark.html", "Blindspark Live Refresh",
    "As an appliance user, I want the page to refresh data automatically so that it feels like an appliance dashboard.",
    "Polls overview/apps/subsidy every 5s, wizard every 30s, lease every 30s, services every 15s. Refreshes on visibility change.",
    "Open simple dashboard, wait, verify data refreshes.",
    refs="dashboard/blindspark.html:1671-1678"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "docs.html", "Documentation Reader",
    "As a user or operator, I want to read HiveRelay documentation so that I can learn how to install, configure, and develop on the network.",
    "Static docs page with Quick Start, Node Operator Guide, Developer SDK, Architecture, Network & Discovery, Hyper Gateway, API Reference sections.",
    "Open /docs, verify sections render.",
    refs="dashboard/docs.html:284-959"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "docs.html", "Copy Code Buttons",
    "As a documentation reader, I want to copy code snippets with one click so that I can paste them into a terminal.",
    "Each code block has Copy button that copies text and shows Copied! for 2s.",
    "Click a code copy button.",
    refs="dashboard/docs.html:971-1025"))

rows.append(row(nid(), "1-Catalog", "Dashboard", "docs.html", "Mobile Sidebar & Active Section Tracking",
    "As a documentation reader, I want a navigable sidebar that highlights my current section so that I can jump around the docs.",
    "Fixed sidebar with sections. Hamburger toggles sidebar on mobile. Scroll updates active link based on visible heading.",
    "Open /docs on narrow viewport, toggle sidebar, scroll.",
    refs="dashboard/docs.html:232-281,1028-1067"))

# ============================================================================
# CLI (packages/core/cli/)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "Global --version / -v",
    "As a user or script, I want to quickly check the installed package version so that I can verify compatibility.",
    "Prints version from package.json and exits 0. No banner or dependency init.",
    "Run p2p-hiverelay --version and -v.",
    refs="packages/core/cli/index.js:43-46"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/setup.js", "setup — Interactive Setup Wizard",
    "As a first-time operator, I want a TUI that walks me through profile, resources, services, transports, and network settings so that I can generate a valid config.json.",
    "Presents profile choices, prompts storage path, resource limits, optional plugins, relay/seeding toggles, API port, regions, transports, Lightning, advanced settings, saves ~/.hiverelay/config.json. Optionally starts node immediately.",
    "Run p2p-hiverelay setup and complete prompts.",
    refs="packages/core/cli/index.js:163-169; packages/core/cli/setup.js:131-498"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/manage.js", "manage / tui — Live Management Console",
    "As an operator, I want an interactive console to inspect and mutate a running relay without memorizing HTTP endpoints.",
    "Connects to /health, offers menu: Dashboard, Services, Resources, Transports, Seeding & Apps, Anchors, Operating Mode, Network, Subsidy, Custody, Exit. Actions call HTTP API with operator key auth.",
    "Run p2p-hiverelay manage (or tui) against a running node.",
    refs="packages/core/cli/index.js:173-178; packages/core/cli/manage.js:108-990"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "start — Start Relay Node",
    "As an operator, I want to start the relay with one command so that it serves API and joins the network.",
    "Parses flags, loads config, instantiates RelayNode, calls start(), waits for started event, prints dashboard URL and pubkey.",
    "Run p2p-hiverelay start; verify /health responds.",
    refs="packages/core/cli/index.js:181-215; packages/core/core/relay-node/index.js:911-2086"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "start flags (--config, --mode, --port, etc.)",
    "As an operator, I want to override config and mode from the command line so that I can test different setups quickly.",
    "CLI accepts --config, --mode, --port, --host, --storage, --maxStorage, --acceptMode, --plugins, --no-api, --no-dashboard, --bootstrap, etc.",
    "Run start with each override and inspect /api/status.",
    refs="packages/core/cli/index.js:50-160"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "seed — Seed a drive key manually",
    "As an operator, I want to pin a Hyperdrive key on my relay from the CLI so that it hosts specific content.",
    "CLI command accepts a 64-hex key and optional name, POSTs to /seed or local seed API.",
    "Run p2p-hiverelay seed <key> --name myapp.",
    refs="packages/core/cli/index.js"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "unseed — Remove a seeded drive",
    "As an operator, I want to stop hosting a drive from the CLI so that I can free storage.",
    "CLI command accepts key, calls unseed API, optionally forgets registry entry.",
    "Run p2p-hiverelay unseed <key>.",
    refs="packages/core/cli/index.js"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "status — Print node status",
    "As an operator or script, I want a quick text summary of node status so that I can monitor from the terminal.",
    "Fetches /api/status and prints formatted output.",
    "Run p2p-hiverelay status.",
    refs="packages/core/cli/index.js"))

rows.append(row(nid(), "1-Catalog", "CLI", "cli/index.js", "wizard — CLI first-run setup",
    "As an operator, I want to complete the first-run wizard from the terminal so that I can configure headlessly.",
    "CLI prompts for relay name, payout, accept mode, completes wizard via HTTP API.",
    "Run p2p-hiverelay wizard on fresh node.",
    refs="packages/core/cli/index.js; packages/core/core/wizard.js"))

# ============================================================================
# CORE API (packages/core/core/relay-node/api*.js)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Core API", "api-health.js", "GET /health",
    "As a monitor or load balancer, I want a lightweight liveness endpoint so that I can confirm the node is up.",
    "Returns 200 JSON with status, uptime, version, publicKey when API is ready.",
    "curl http://localhost:9100/health.",
    refs="packages/core/core/relay-node/api-health.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-status-read.js", "GET /api/status",
    "As an operator, I want a machine-readable status snapshot so that I can inspect mode, version, network, and config.",
    "Returns JSON with mode, version, publicKey, uptime, network config, transports, plugins, accept mode, storage cap, etc.",
    "curl http://localhost:9100/api/status.",
    refs="packages/core/core/relay-node/api-status-read.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-overview.js", "GET /api/overview",
    "As a dashboard or monitoring tool, I want a summary of node metrics so that I can render health panels.",
    "Returns connections, apps kept alive, data stored/relayed, peers, memory, storage, circuits, errors, subsidy, payment, lease stats.",
    "curl http://localhost:9100/api/overview.",
    refs="packages/core/core/relay-node/api-overview.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-metrics.js", "GET /api/metrics (Prometheus)",
    "As an operator, I want Prometheus-compatible metrics so that I can scrape with standard tools.",
    "Returns text/plain metrics for connections, bytes, requests, storage, peers, etc.",
    "curl http://localhost:9100/api/metrics.",
    refs="packages/core/core/relay-node/api-metrics.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-history.js", "GET /api/history",
    "As a dashboard, I want time-series samples so that I can render charts.",
    "Returns connection and traffic samples for requested minutes window.",
    "curl http://localhost:9100/api/history?minutes=60.",
    refs="packages/core/core/relay-node/api-history.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-apps-read.js", "GET /api/apps",
    "As a dashboard, I want the list of seeded apps so that I can render the apps table.",
    "Returns array of seeded app records with metadata, uptime, bytes served.",
    "curl http://localhost:9100/api/apps.",
    refs="packages/core/core/relay-node/api-apps-read.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-seed-core.js", "POST /seed — Manual seed request",
    "As an operator or publisher, I want to ask the relay to pin a drive key so that it stays online.",
    "Accepts key, optional name, maxStorageBytes, etc. Adds to registry and starts seeding.",
    "curl -X POST -d '{\"key\":\"...\"}' http://localhost:9100/seed.",
    refs="packages/core/core/relay-node/api-seed-core.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-unseed-actions.js", "POST /unseed — Stop seeding",
    "As an operator or publisher, I want to stop hosting a drive so that I can free storage.",
    "Accepts key, optionally forgets registry entry.",
    "curl -X POST -d '{\"key\":\"...\"}' http://localhost:9100/unseed.",
    refs="packages/core/core/relay-node/api-unseed-actions.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-registry-status.js", "GET/POST /api/registry/*",
    "As an operator, I want to inspect and control the seed registry so that I can manage approvals.",
    "GET pending, POST approve/reject/auto-accept. Controls seed acceptance policy and pending requests.",
    "curl registry endpoints with operator auth.",
    refs="packages/core/core/relay-node/api-registry-status.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-network-state.js", "GET /api/network",
    "As a user, I want to discover relays on the network so that I can choose peers.",
    "Returns list of known relays with status, region, stats, transport badges. Detailed variant with operator auth.",
    "curl http://localhost:9100/api/network and /api/network?detailed=1.",
    refs="packages/core/core/relay-node/api-network-state.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-reputation-read.js", "GET /api/reputation",
    "As a user, I want a reputation leaderboard so that I can compare relays.",
    "Returns relay reputation scores, latency, uptime, bytes served, challenges.",
    "curl http://localhost:9100/api/reputation.",
    refs="packages/core/core/relay-node/api-reputation-read.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-subsidy.js", "GET/POST /api/subsidy/*",
    "As an operator, I want to inspect subsidy earnings and set a payout destination so that I can receive network rewards.",
    "GET returns accrued sats, daily cap, stats. POST /destination sets payout address.",
    "curl subsidy endpoints with operator auth.",
    refs="packages/core/core/relay-node/api-subsidy.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-lease.js", "GET/POST /api/lease/*",
    "As an operator, I want to configure paid seeding leases and view lease earnings so that I can monetize storage.",
    "GET returns lease config/earnings. POST /config sets satsPerGiBDay.",
    "curl lease endpoints with operator auth.",
    refs="packages/core/core/relay-node/api-lease.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-usage-telemetry.js", "GET /api/usage",
    "As an operator, I want signed usage receipts so that I can verify payout-eligible activity.",
    "Returns signed usage receipts and totals.",
    "curl http://localhost:9100/api/usage with operator auth.",
    refs="packages/core/core/relay-node/api-usage-telemetry.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-manage", "POST /api/manage/config",
    "As an operator, I want to mutate relay configuration via API so that I can change settings remotely.",
    "Accepts config keys like maxStorageBytes; persists and applies live where possible.",
    "curl -H auth -X POST -d '{\"maxStorageBytes\":...}' /api/manage/config.",
    refs="packages/core/core/relay-node/api-service-config.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-mode-transport.js", "POST /api/manage/mode",
    "As an operator, I want to change the relay operating mode via API so that I can adapt deployment scenario.",
    "Validates mode, applies, persists, returns applied changes.",
    "curl -H auth -d '{\"mode\":\"private\"}' /api/manage/mode.",
    refs="packages/core/core/relay-node/api-mode-transport.js:99-163"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-mode-transport.js", "POST /api/manage/transport",
    "As an operator, I want to enable/disable a transport via API so that I can control network exposure.",
    "Validates transport name, updates config.transports, persists, notes restart may be required.",
    "curl -H auth -d '{\"transport\":\"tor\",\"enabled\":true}' /api/manage/transport.",
    refs="packages/core/core/relay-node/api-mode-transport.js:165-212"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-service-management.js", "GET/POST /api/manage/services/*",
    "As an operator, I want to list, configure, and restart services so that I can manage plugins.",
    "GET available/running services, POST config to enable/disable, POST restart to apply.",
    "curl service management endpoints with operator auth.",
    refs="packages/core/core/relay-node/api-service-management.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-custody-management.js", "POST /api/custody/*",
    "As a custody participant, I want to publish custody intents, commits, proofs, and witness tombstones so that I can manage blind-custody lifecycle.",
    "Endpoints for intent, commit, source-retired, proof, non-serving-proof, expiry-witness, status.",
    "POST custody endpoints with publisher/operator auth.",
    refs="packages/core/core/relay-node/api-custody-management.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-fork-proofs.js", "POST /api/forks/proof",
    "As a developer, I want to publish fork evidence so that equivocation is recorded.",
    "Accepts signed fork proof, validates, stores.",
    "curl -X POST -d proof /api/forks/proof.",
    refs="packages/core/core/relay-node/api-fork-proofs.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-device-pairing.js", "POST /api/pairing/*",
    "As a user, I want to pair devices via a short numeric code so that multi-device setup is easy.",
    "Endpoints to create/claim pairing codes.",
    "Use client pairing methods or curl pairing endpoints.",
    refs="packages/core/core/relay-node/api-device-pairing.js; packages/client/pairing.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-index-proxy.js", "GET /api/index/room and /index/*",
    "As a PearBrowser user, I want a queryable index of relay catalog data so that I can discover content without trusting one relay.",
    "Proxies to index-sidecar: room key, pins, relays, manifests, verifications with JMESPath-like queries.",
    "curl /api/index/room and /index/pins?query=....",
    refs="packages/core/core/relay-node/api-index-proxy.js; services/index-sidecar/"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-gateway-stats.js", "GET /api/gateway",
    "As an operator, I want gateway metrics so that I can monitor file-serving load.",
    "Returns cachedDrives, totalRequests, totalBytesServed.",
    "curl /api/gateway.",
    refs="packages/core/core/relay-node/api-gateway-stats.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-wizard-actions.js", "GET/POST /api/wizard/*",
    "As a new operator, I want the first-run wizard API so that I can configure the node.",
    "GET snapshot, POST goto/relay-name/payout/accept-mode/complete/reset. Persists wizard state and applies config on complete.",
    "Walk wizard steps via curl.",
    refs="packages/core/core/relay-node/api-wizard-actions.js; packages/core/core/wizard.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-catalog-read.js", "GET /catalog.json",
    "As a user, I want a public catalog of seeded content so that I can discover apps.",
    "Returns paginated catalog entries with metadata. Query params for page/pageSize.",
    "curl /catalog.json and /catalog.json?pageSize=200.",
    refs="packages/core/core/relay-node/api-catalog-read.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "api-dashboard-routes.js", "GET /dashboard /wizard and static pages",
    "As an operator, I want the dashboard HTML served from the relay so that I can manage via browser.",
    "Serves full or simple dashboard based on ui.simple. Injects hiverelay-ui-token meta when ui.exposeToken. Sets security headers.",
    "curl /dashboard, inspect HTML for token meta and CSP headers.",
    refs="packages/core/core/relay-node/api-dashboard-routes.js; api-dashboard-html.js"))

rows.append(row(nid(), "1-Catalog", "Core API", "WebSocket /ws", "Live WebSocket feed",
    "As a dashboard, I want live updates so that metrics update without polling.",
    "WebSocket at /ws emits update, overview, network, reputation messages. Dashboard pages subscribe.",
    "Open /ws with a WS client, verify messages.",
    refs="packages/core/core/relay-node/api.js WebSocket handling"))

# ============================================================================
# CLIENT SDK (packages/client/)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "HiveRelayClient construction",
    "As a developer, I want to create a client with storage path or custom swarm/store/keyPair so that I can control identity and networking.",
    "Accepts string path or options object; sets defaults, initializes relay/drive maps, capability cache, fork detector.",
    "Instantiate client in simple and advanced modes.",
    refs="packages/client/index.js:143-270"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.start()",
    "As a developer, I want to initialize storage, swarm, discovery, registry, and seed retry queue so that the client is ready.",
    "Creates corestore/swarm if owned, loads bootstrap cache, joins discovery topics, starts registry, reconnect loop, health checks, emits ready/started.",
    "Call start() and await ready event.",
    refs="packages/client/index.js:288-400"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.publish()",
    "As a developer, I want to publish files or a directory to a Hyperdrive and request relay seeding so that others can fetch by key.",
    "Accepts file array or directory path. Supports appId reuse, explicit key, encryptionKey. Joins swarm, persists mapping, optionally seeds.",
    "Publish files and directory, verify drive key.",
    refs="packages/client/index.js:420-522"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.open()",
    "As a developer, I want to open and replicate a remote Hyperdrive by key so that I can read its files.",
    "Checks quarantine via ForkDetector, attaches listeners, joins swarm, optionally waits for update, emits opened/open-timeout/reader-replica-joined.",
    "Open a known drive, read a file.",
    refs="packages/client/index.js:540-657"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "get/put/list helpers",
    "As a developer, I want simple helpers to read, write, and list files in an opened drive.",
    "get returns drive.get(path), put writes buffer/string, list returns entry keys resilient to lifecycle errors.",
    "Use get/put/list on an opened drive.",
    refs="packages/client/index.js:662-700"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.closeDrive()",
    "As a developer, I want to close one drive and leave its swarm topic so that I can free resources without destroying the whole client.",
    "Removes fork listeners, leaves topic, closes drive, deletes from this.drives.",
    "Close a drive and verify it's removed.",
    refs="packages/client/index.js:705-720"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.seed()",
    "As a publisher, I want to broadcast a signed seed request to connected relays so that my content is replicated and stays online.",
    "Computes discovery key, sets commitments, signs request, broadcasts via Protomux and registry, collects acceptances until target/floor or timeout, supports persistent retry queue.",
    "Seed a published drive and wait for acceptances.",
    refs="packages/client/index.js:732-941"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Persistent seed retry queue",
    "As a publisher, I want failed seed requests to be retried across process restarts so that transient issues don't leave content unseeded.",
    "Loads/saves pending-seeds.json, exponential backoff 30s-1h, max 50 attempts. getPendingSeeds, cancelPendingSeed, retryPendingSeedsNow.",
    "Seed with no relays, restart client, verify pending retries.",
    refs="packages/client/index.js:988-1122"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.unseed()",
    "As a publisher, I want to ask relays to stop seeding my app so that I can take content down.",
    "Requires publisher keypair, signs (appKey + 'unseed' + timestamp), broadcasts, emits unseed-published.",
    "Unseed a previously seeded drive.",
    refs="packages/client/index.js:1132-1178"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Circuit relay (reserveRelay, connectViaRelay, sendCircuitData)",
    "As a developer, I want NAT traversal via circuit relay so that firewalled devices can communicate.",
    "Reserve slot, dial target through relay, forward data on established circuit.",
    "Reserve and send data through a relay.",
    refs="packages/client/index.js:1182-1260,1331-1348"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Forward relay transport",
    "As a developer, I want a Duplex stream through a relay to another peer so that I can build proxied protocols.",
    "Opens forward channel, returns streamx Duplex for framed data. Supports single forward per relay connection.",
    "Open forward stream and exchange data.",
    refs="packages/client/index.js:1278-1315"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Relay status and catalog helpers",
    "As a developer, I want to inspect connected relays and discover apps they seed so that I can build dashboards or picker UIs.",
    "getRelays, getServiceCatalog, getAvailableApps, getAvailableAppsBySource, getSeedStatus.",
    "Call helpers after connecting to relays.",
    refs="packages/client/index.js:1355-1490"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Reader replicas",
    "As a user or app, I want to volunteer to re-seed drives I opened so that content gains redundancy.",
    "enableReaderReplica joins drive as server without being author. mirror/unmirror aliases. Tracks _readerReplicas.",
    "Open a drive as reader replica.",
    refs="packages/client/index.js:1505-1563"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Community replicas",
    "As an app developer, I want users to optionally help seed a list of public drives so that redundancy scales.",
    "registerCommunityReplicas stores manifest; enable/disable mirrors all or one; auto-mirrors newly registered if opted in.",
    "Register community replicas and opt in.",
    refs="packages/client/index.js:1578-1689"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Replication status / durability",
    "As a publisher, I want to know whether my content is healthy, degraded, or critical so that I can re-broadcast if needed.",
    "getReplicationStatus returns current/target/floor/health. getDurableStatus checks peers and remote length. waitForDurable polls. getReplicationOverview aggregates.",
    "Check replication status after seeding.",
    refs="packages/client/index.js:1705-1822"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "enableReplicationMonitor()",
    "As a publisher, I want the client to automatically re-broadcast seed requests when replication drops to critical so that content stays available.",
    "Sets interval (default 5 min). If current <= floor, calls seed() and emits replication-rebroadcast. Returns {stop} handle.",
    "Enable monitor, simulate low replication, verify rebroadcast.",
    refs="packages/client/index.js:1865-1908"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Identity export/import",
    "As a user, I want to copy my publishing identity to another device so that either device can publish under the same key.",
    "exportIdentity returns version/publicKey/secretKey. importIdentity validates and replaces keyPair, emits identity-imported.",
    "Export identity, import into new client, verify same pubkey.",
    refs="packages/client/index.js:1949-1976"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Device attestation / delegation",
    "As a primary device, I want to sign a time-limited certificate authorizing a secondary device's pubkey to publish on my behalf so that I can revoke it without rotating my main key.",
    "createDeviceAttestation signs cert with TTL and label. Static verifyDeviceAttestation checks version, expiry, signature.",
    "Create attestation, verify, use for delegated publish.",
    refs="packages/client/index.js:1989-2044"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "createCertRevocation()",
    "As the primary device, I want to revoke a device attestation so that relays stop accepting it.",
    "Validates cert primaryPubkey matches client identity, delegates to core createRevocation.",
    "Create then revoke attestation.",
    refs="packages/client/index.js:2063-2078"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Seeding manifest",
    "As an author, I want to publish a signed list of recommended relays for my drives so that readers know where to fetch.",
    "createSeedingManifest signs manifest. publishSeedingManifest POSTs to /api/authors/seeding.json. fetchSeedingManifest GETs and verifies by pubkey.",
    "Create, publish, and fetch manifest.",
    refs="packages/client/index.js:2100-2141,2614-2638"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Atomic blind custody HTTP methods",
    "As a developer, I want to publish custody intents/commits/proofs/witness tombstones to relays so that I can manage blind-custody lifecycle.",
    "publishCustodyIntent, publishCustodyCommit, publishSourceRetired, recordCustodyProof, recordCustodyNonServingProof, recordCustodyExpiryWitness, getCustodyStatus POST/GET /api/custody/....",
    "Call custody methods with mock relay.",
    refs="packages/client/index.js:2153-2303"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "splitForCustody / reconstructFromCustody",
    "As a developer, I want to blind-custody a secret encryption key across a relay quorum using PVSS so that no single relay can recover it, and recover later with threshold shares.",
    "splitForCustody splits secret to guardian pubkeys, writes public share bundle to hypercore, signs v2 intent, publishes per relay, seeds addressKey, polls receipts, publishes commit. reconstructFromCustody resolves bundle/threshold, reads, decrypts shares, reconstructs dealer key.",
    "Run blind-custody E2E test.",
    refs="packages/client/index.js:2337-2517"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Capability documents",
    "As a developer, I want to inspect relay capabilities and verify signatures/out-of-band pins so that I can choose trustworthy relays.",
    "Fetches /.well-known/hiverelay.json or /api/capabilities. Verifies signature, expectedPubkey pin, staleness, future skew. Emits capability errors.",
    "Fetch capabilities for a local relay with and without signature.",
    refs="packages/client/index.js:2708-2785"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Quorum selection and comparison",
    "As a developer, I want to select a diverse relay quorum and compare responses to detect equivocation.",
    "refreshCapabilityCache fetches docs with TTL. selectQuorum uses core selector. describeQuorum returns summary. queryQuorum and queryQuorumWithComparison issue parallel HTTP queries and report divergence.",
    "Select quorum, query endpoints, inject divergence.",
    refs="packages/client/index.js:2787-2959"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "getStriped multi-relay read",
    "As a privacy-conscious reader, I want to fetch a file in ranged stripes from different relays so that no single relay sees the whole object.",
    "Probes size via Range request, splits ranges, fetches from different relays, verifies stripe lengths, concatenates. Falls back to full GET if Range unsupported.",
    "getStriped a file from two relays.",
    refs="packages/client/index.js:2962-3083"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Relay pinning",
    "As an operator, I want to pin a relay's expected pubkey so that a mismatched capability doc fails fast.",
    "pinRelay adds URL->pubkey mapping; unpinRelay removes; pinnedRelays snapshots.",
    "Pin a relay, fetch capabilities with wrong pubkey, verify rejection.",
    refs="packages/client/index.js:3095-3120"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Fork proof publishing",
    "As a developer, I want to broadcast signed fork evidence to relays so that equivocation is recorded.",
    "Adapts proof shape, signs with signForkProof, POSTs to /api/forks/proof per relay URL, returns results.",
    "Publish fork proof to mock relays.",
    refs="packages/client/index.js:3138-3171"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "isDriveQuarantined",
    "As a developer, I want to check whether a drive is quarantined due to an unresolved fork so that I can refuse to open it.",
    "Delegates to ForkDetector.isQuarantined.",
    "Check quarantine on a drive with simulated fork.",
    refs="packages/client/index.js:3181-3185"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Pairing code methods",
    "As a user, I want to pair a second device by typing a short numeric code instead of copying keys.",
    "createPairingCode attaches PairingManager and generates code. claimPairingCode attaches and claims.",
    "Create code on one client, claim on another.",
    refs="packages/client/index.js:3197-3226; packages/client/pairing.js"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "Service RPC",
    "As a developer, I want to call named services on relays and subscribe to live events so that I can use relay services.",
    "callService sends MSG_REQUEST over Protomux, resolves on MSG_RESPONSE, rejects on MSG_ERROR/timeout. subscribeService routes MSG_EVENT to listeners and unsubscribes when last listener detaches.",
    "Call identity service, subscribe to events.",
    refs="packages/client/index.js:3236-3322"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "verifySeeded / proveSeeded",
    "As a developer, I want to verify that a relay genuinely holds and serves my drive, and obtain signed proofs of retrievability.",
    "verifySeeded opens drive, downloads cores, checks relay peer and length. proveSeeded samples random blocks via HTTP /api/proof/retrievability or storage-proof.prove service, verifies signed proofs in isolated sandbox.",
    "Verify and prove a seeded drive.",
    refs="packages/client/index.js:3343-3520"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "fetchAccountingReceipt",
    "As an operator, I want to fetch a relay's signed accounting receipt and verify it locally so that I can audit counters.",
    "GET /api/accounting/receipt, verifies signature with verifyAccountingReceipt, optionally pins expectedPubkey.",
    "Fetch receipt from local relay.",
    refs="packages/client/index.js:2655-2686"))

rows.append(row(nid(), "1-Catalog", "Client SDK", "index.js", "client.destroy()",
    "As a developer, I want to cleanly shut down timers, drives, swarm topics, and persistence so that no resources leak.",
    "Clears timers, saves pending seeds/fork records, leaves topics, closes drives, stops registry/pairing, destroys owned swarm/store, emits destroyed.",
    "Start client, then destroy and verify cleanup.",
    refs="packages/client/index.js:4208-4317"))

# ============================================================================
# SERVICES (packages/services/ and services/index-sidecar/)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Services", "outboxlog", "Single-writer signed outbox log",
    "As a Pear app developer, I want each app instance to have a single-writer signed replay-protected outbox log on the relay so that my app can sync small encrypted records across devices.",
    "Operator enables outboxlog. Client gets token, creates outbox, appends signed records, reads via GET/SSE. Optional hypercore journal persists per-outbox cores.",
    "Enable plugin, create outbox, append, read, subscribe to SSE.",
    refs="packages/services/builtin/outboxlog/index.js; http-adapter.js; packages/core/core/relay-node/api-outboxlog-http-adapter.js"))

rows.append(row(nid(), "1-Catalog", "Services", "witnesslog", "Signed availability observations",
    "As a relay operator or monitoring peer, I want to publish and query signed availability observations about other relays/cores so that the network can detect outages.",
    "WitnessLog wraps OutboxLog namespace. Witness submits signed record; readers query paginated records or SSE markers. Redacted by default.",
    "Enable plugin, append witness record, query target.",
    refs="packages/services/builtin/witnesslog/index.js; record.js; http-adapter.js; packages/core/core/relay-node/api-witnesslog-http-adapter.js"))

rows.append(row(nid(), "1-Catalog", "Services", "repairticket", "Signed repair requests",
    "As a relay operator or agent, I want to file, claim, repair, and close signed repair tickets for missing/corrupted cores so that the network self-heals.",
    "RepairTicket wraps OutboxLog namespace. Ticket/claim/receipt/close records. tickets() builds authoritative summaries with anti-forgery rules.",
    "Enable plugin, create ticket, claim, repair, close.",
    refs="packages/services/builtin/repairticket/index.js; record.js; http-adapter.js; packages/core/core/relay-node/api-repairticket-http-adapter.js"))

rows.append(row(nid(), "1-Catalog", "Services", "shard-store", "Content-addressed blind blob store",
    "As a custody participant, I want to PUT, GET, and prove possession of encrypted custody shards by hash so that the relay hosts blind shards without seeing plaintext.",
    "Client PUTs ciphertext with signed X-Shard-Pin. Service hashes, authorizes pin, stores once, ref-counts. GET returns bytes; optional nonce triggers signed retrieval proof. Sweep/evict expired pins.",
    "Enable plugin, PUT shard, GET shard, request proof.",
    refs="packages/services/builtin/shard-store/index.js; shard-engine.js; shard-pin.js; shard-proof.js; http-adapter.js; packages/core/core/relay-node/api-shard-http-adapter.js"))

rows.append(row(nid(), "1-Catalog", "Services", "poker", "Card-blind signed-log substrate",
    "As a game developer, I want a relay-hosted append-only signed log per game table so that players can make moves and subscribe to live events without the relay seeing hidden payloads.",
    "Operator enables poker bundle. Authorized client creates table. Players submit signed moves. Readers GET state/log. Live subscribers connect WS /api/poker/<table>/events. Idle tables reaped.",
    "Enable plugin, create table, submit moves, subscribe to events.",
    refs="packages/services/builtin/poker/index.js; signed-log.js; http-adapter.js; ws-adapter.js; packages/core/core/relay-node/api-poker-http-adapter.js"))

rows.append(row(nid(), "1-Catalog", "Services", "notify", "Encrypted P2P wakeup notifications",
    "As an app developer, I want to send encrypted wake-up pushes to offline peers through the relay without exposing plaintext.",
    "Device binds provider, registers device, installs receive/send caps. Sender calls send; relay validates caps, enforces quotas, persists, calls provider adapter. Watch mode subscribes to sources and fires wakes.",
    "Enable plugin, register device, install caps, send notification, watch source.",
    refs="packages/services/builtin/notify-service.js; packages/core/core/relay-node/api-notify.js"))

rows.append(row(nid(), "1-Catalog", "Services", "identity", "secp256k1 <-> Ed25519 identity bridge",
    "As a developer, I want to prove that my Lightning/Nostr/Bitcoin secp256k1 key owns my Hyperswarm Ed25519 app key so that users can verify app authorship.",
    "Developer authenticates via LNURL-auth, signs attestation binding Ed25519 app key -> secp256k1 dev key. AttestationService verifies Schnorr signature, checks freshness, persists. DeveloperStore resolves profile via Nostr kind:0.",
    "Enable identity service, create LNURL challenge, sign callback, submit attestation, resolve identity.",
    refs="packages/services/identity/index.js; attestation.js; developer-store.js; lnurl-auth.js; crypto.js; packages/services/builtin/identity-service.js"))

rows.append(row(nid(), "1-Catalog", "Services", "index-sidecar", "Tier-2 queryable P2P index",
    "As a PearBrowser desktop user, I want a publicly replicable, queryable index of relay catalog data so that I can discover apps/pins/relays without trusting one relay's HTTP API.",
    "Sidecar polls /.well-known/hiverelay.json and /catalog.json, projects rows into schema-sheets room on corestore-7, announces on Hyperswarm. Relay proxies /api/index/room and /index/*.",
    "Run sidecar, verify /api/index/room returns room key, query /index/pins.",
    refs="services/index-sidecar/index.mjs; lib/projector.js; lib/room.js; lib/server.js; packages/core/core/relay-node/api-index-proxy.js"))

rows.append(row(nid(), "1-Catalog", "Services", "services/index.js", "Public export barrel",
    "As a downstream developer, I want a single import path exposing all service classes and helpers.",
    "Re-exports AIService, IdentityService, SchemaService, SLAService, StorageService, ZKService, ArbitrationService, StorageProofService, ShardStoreService, OutboxLogApp, WitnessLogApp, RepairTicketApp, NotifyService, etc.",
    "Import from p2p-hiveservices and verify exports exist.",
    refs="packages/services/index.js; packages/services/README.md",
    notes="README mentions createBuiltInServices({enabled: [...]}) but function is not exported from index.js"))

# ============================================================================
# GATEWAY (packages/core/gateway/)
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Gateway", "hyper-gateway.js", "Hyperdrive HTTP Gateway /v1/hyper/:key/*",
    "As a mobile user or browser, I want to fetch a published Hyperdrive by public key over HTTP so that I can load apps without P2P stack.",
    "GET /v1/hyper/<key>/path. Validates key, returns 404 if not seeded, 403 if blind+publicOnly. Resolves index.html, rewrites HTML root-relative links, streams files with Accept-Ranges, supports single byte-range 206, directory listings as JSON.",
    "Publish drive, seed, curl gateway URLs including Range requests.",
    refs="packages/core/gateway/hyper-gateway.js:219-688"))

rows.append(row(nid(), "1-Catalog", "Gateway", "gateway/server.js", "Standalone Gateway Server",
    "As an operator, I want a lightweight public file-serving gateway without the full management API so that downloads don't starve control plane.",
    "node packages/core/gateway/server.js --port ... <keys...>. Owns corestore+swarm, seeds supplied keys, serves /v1/hyper/*, POST /v1/seed, GET /health, CORS.",
    "Run standalone gateway, seed key, fetch files.",
    refs="packages/core/gateway/server.js:73-205"))

rows.append(row(nid(), "1-Catalog", "Gateway", "relay-node/gateway-server.js", "Relay-Mounted Separate Gateway Server",
    "As an operator, I want file downloads on a separate port from the management API.",
    "When config.gatewayPort differs from apiPort, RelayNode constructs GatewayServer sharing HyperGateway. Serves /v1/hyper/*, /catalog.json, /health with rate limiting.",
    "Set gatewayPort, start relay, curl gateway port.",
    refs="packages/core/core/relay-node/gateway-server.js:31-217"))

rows.append(row(nid(), "1-Catalog", "Gateway", "api-route-mounts.js", "Inline Gateway on Control Plane",
    "As a developer, I want the same /v1/hyper/* URLs whether split gateway or single-port API.",
    "RelayAPI instantiates HyperGateway. If gatewayPort == apiPort, handles /v1/hyper/* inline; otherwise GatewayServer owns it.",
    "Start relay without gatewayPort, verify /v1/hyper works on API port.",
    refs="packages/core/core/relay-node/api-route-mounts.js:38-40; packages/core/core/relay-node/api.js:400,721-723"))

rows.append(row(nid(), "1-Catalog", "Gateway", "api-gateway-stats.js", "GET /api/gateway metrics",
    "As an operator, I want to see how many drives are cached and how many bytes the gateway has served.",
    "GET /api/gateway returns JSON {cachedDrives, totalRequests, totalBytesServed}.",
    "curl /api/gateway after serving gateway requests.",
    refs="packages/core/core/relay-node/api-gateway-stats.js"))

# ============================================================================
# EXAMPLES
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Examples", "node-app", "Node.js Publish/Seed Example",
    "As a Node.js developer, I want the smallest working example that publishes content and asks the network to keep it online.",
    "Creates storage, starts HiveRelayClient, publishes inline HTML/CSS/manifest, seeds with replicationFactor 3, calls identity service, prints relay count and apps.",
    "cd examples/node-app && npm install && node index.js.",
    refs="examples/node-app/index.js"))

rows.append(row(nid(), "1-Catalog", "Examples", "pear-app", "Pear Runtime Example",
    "As a Pear app developer, I want to see how to use HiveRelay inside Pear/Bare runtime.",
    "Detects Pear.config.storage or falls back, creates corestore+swarm, publishes+seeds, lists relays/apps.",
    "cd examples/pear-app && npm install && pear run .",
    refs="examples/pear-app/index.js"))

rows.append(row(nid(), "1-Catalog", "Examples", "hiveworm-app", "HiveWorm Browser Game",
    "As a player, I want to join a shared relay-anchored worm world from my browser, move, eat, grow, and persist identity.",
    "Browser loads index.html, generates/loads Ed25519 identity, fetches state, signs SPAWN/move POSTs, applies log entries, grows on food, dies on collision, backup/import seed.",
    "Start relay with enableHiveworm, serve directory, open in browser with ?relay=...",
    refs="examples/hiveworm-app/game.js; network.js; identity.js; world.js; input.js",
    notes="README notes WS endpoint is being built; client falls back to polling"))

rows.append(row(nid(), "1-Catalog", "Examples", "pearbrowser-marketplace-demo", "PearBrowser Marketplace Demo",
    "As a PearBrowser user, I want to open a published app and confirm it is served through gateway and listed in catalog.",
    "App parses drive key from gateway path, fetches /catalog.json, displays gateway state, catalog state, app key, row count.",
    "npm run demo:pearbrowser (or :once), open printed gateway URL in PearBrowser.",
    refs="examples/pearbrowser-marketplace-demo/index.html; app.js; manifest.json; scripts/pearbrowser-marketplace-demo.js"))

# ============================================================================
# STANDALONE
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Standalone", "server.js", "Standalone Block Storage Server",
    "As a developer evaluating Holepunch stack, I want a minimal server that accepts blocks over Hyperswarm/protomux-rpc and stores them in a Hypercore.",
    "Opens storage, creates Hypercore named block-storage, announces discovery key, replicates corestore, exposes store-block/get-block/get-info RPC methods.",
    "cd standalone && npm run server, copy pubkey.",
    refs="standalone/server.js"))

rows.append(row(nid(), "1-Catalog", "Standalone", "client.js", "REPL Client",
    "As a tester, I want an interactive client that can store, retrieve, benchmark, and inspect blocks.",
    "Joins server's topic, starts REPL with store/get/random/info/bench/quit commands.",
    "npm run client -- <server-key>; type store hello, get 0, bench 100.",
    refs="standalone/client.js"))

rows.append(row(nid(), "1-Catalog", "Standalone", "demo.js", "Self-Contained Demo",
    "As a reviewer, I want a single command that proves block-storage flow end-to-end without external DHT.",
    "Creates local testnet, spins in-process server and client, stores/reads blocks, runs benchmark, verifies replication lengths.",
    "cd standalone && npm run demo.",
    refs="standalone/demo.js"))

rows.append(row(nid(), "1-Catalog", "Standalone", "test.js", "Standalone Test Suite",
    "As a maintainer, I want an automated test suite for the standalone block-storage implementation.",
    "Mini test runner covers single/multiple blocks, binary/JSON, out-of-range, metadata, 1MB blocks, rapid writes, replication, empty blocks. Exits non-zero on failure.",
    "cd standalone && npm test.",
    refs="standalone/test.js"))

# ============================================================================
# PACKAGING / DEPLOYMENT
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Packaging", "umbrel-app", "Umbrel App Store Manifest",
    "As an Umbrel user, I want to install Blindspark from the App Store and have a one-page dashboard.",
    "Manifest declares id blindspark, category networking, version, description, pinned multi-arch image behind app_proxy, persistent data in APP_DATA_DIR/data.",
    "Validate with Umbrel app validator; sideload docker-compose.yml with env vars.",
    refs="umbrel-app/umbrel-app.yml; umbrel-app/docker-compose.yml"))

rows.append(row(nid(), "1-Catalog", "Packaging", "startos", "StartOS Service Manifest",
    "As a StartOS user, I want to install Blindspark from a registry with health checks and backups.",
    "Manifest declares id blindspark, version, license, multi-arch tarballs, /data volume, health check web-ui, backup/restore via duplicity, UI over Tor/LAN on port 9100.",
    "make verify IMAGE_DIGEST=... in startos/; sideload blindspark.s9pk.",
    refs="startos/manifest.yaml; startos/README.md"))

rows.append(row(nid(), "1-Catalog", "Packaging", "startos", "StartOS Seed Persistence",
    "As a StartOS user, I want relay identity and dashboard auth token to survive reinstalls as long as data volume is preserved.",
    "On first boot generates /data/.app-seed; later boots reuse. Exports HOME, API_HOST, API_PORT, UI flags, accept mode, max storage. Execs relay CLI.",
    "Run container, verify /data/.app-seed stable across restarts.",
    refs="startos/docker_entrypoint.sh"))

rows.append(row(nid(), "1-Catalog", "Packaging", "startos", "StartOS Health Check",
    "As a StartOS user, I want the service health indicator to turn green once the dashboard responds.",
    "For first 30s returns starting; after 30s curls http://localhost:9100/health and returns result.",
    "Inside container run echo 40000 | ./check-web.sh.",
    refs="startos/check-web.sh"))

# ============================================================================
# LIFECYCLE / OPERATING MODES
# ============================================================================
rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/index.js", "RelayNode.start()",
    "As an operator, I want the relay to load identity, join DHT, start seeding/services, expose API, and be ready in one command.",
    "Creates lifecycle scope, opens corestore, loads/creates identity, constructs swarm/firewall, starts seeder, metrics, protocols, services, health monitors, API, gateway. Emits started. Rolls back on failure.",
    "Run p2p-hiverelay start; verify /health and /status.",
    refs="packages/core/core/relay-node/index.js:911-2086"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/index.js", "RelayNode.stop()",
    "As an operator, I want SIGTERM/restart to flush state and tear down cleanly without losing registry entries.",
    "Drains lifecycle scope, stops timers/feeds/transports/gateway/API/metrics/services/protocols/registry/discovery/federation, persists state, unseeds apps with forget:false, destroys swarm/store, emits stopped.",
    "Start relay, seed app, send SIGINT, verify app re-seeded on next start.",
    refs="packages/core/core/relay-node/index.js:4396-4582"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/index.js", "Operating-Mode Presets",
    "As an operator, I want to pick a preset that configures relay, seeding, discovery, access, custody, and services for my deployment scenario.",
    "Available presets: relay-core, relaykernel, custody-relay, public, standard, private, hybrid, homehive, seed-only, relay-only, stealth, gateway, service-operator, experimental-lab. Each overrides DEFAULT_CONFIG subsets.",
    "Start with --mode homehive and verify /api/status flags.",
    refs="packages/core/core/relay-node/index.js:224-427"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/index.js", "Dashboard Serving Full vs Simple",
    "As an operator, I want a web dashboard; as a home-server user, I want a simpler appliance view.",
    "GET /dashboard serves index.html or blindspark.html based on ui.simple. Simple mode redirects /network etc. to /dashboard. /wizard serves wizard.html. Injects token meta when ui.exposeToken. Sets CSP headers.",
    "Start with HIVERELAY_UI_SIMPLE=true and HIVERELAY_UI_EXPOSE_TOKEN=true, curl /dashboard, inspect meta and headers.",
    refs="packages/core/core/relay-node/api-dashboard-routes.js; api-dashboard-html.js"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/index.js", "First-Run Setup Wizard",
    "As a new operator, I want a short web wizard to name relay, set payout address, choose accept mode.",
    "SetupWizard persists to <storage>/wizard.json. Steps welcome->relay_name->payout->accept_mode->complete. GET/POST /api/wizard/*. On complete merges config and persists. / redirects to /wizard until complete, then /dashboard.",
    "Open / on fresh install, walk wizard, verify /api/wizard isComplete and /dashboard loads.",
    refs="packages/core/core/wizard.js; packages/core/core/relay-node/api-wizard-actions.js"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/api-mode-transport.js", "Runtime Mode Switch",
    "As an authenticated operator, I want to change the relay's operating mode via API and persist it.",
    "POST /api/manage/mode validates mode, applies, persists, returns applied changes; rolls back on persist failure.",
    "curl -H auth -d '{\"mode\":\"private\"}' /api/manage/mode.",
    refs="packages/core/core/relay-node/api-mode-transport.js:99-163"))

rows.append(row(nid(), "1-Catalog", "Lifecycle", "relay-node/api-mode-transport.js", "Transport Toggle",
    "As an authenticated operator, I want to enable/disable individual transports via API.",
    "POST /api/manage/transport validates name, updates config.transports, persists, notes restart may be required.",
    "curl -H auth -d '{\"transport\":\"tor\",\"enabled\":true}' /api/manage/transport.",
    refs="packages/core/core/relay-node/api-mode-transport.js:165-212"))

# ============================================================================
# Write CSV
# ============================================================================
with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=FIELDS)
    writer.writeheader()
    writer.writerows(rows)

print(f"Wrote {len(rows)} features to {CSV_PATH}")
