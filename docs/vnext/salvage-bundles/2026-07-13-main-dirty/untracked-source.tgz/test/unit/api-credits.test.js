import test from 'brittle'
import {
  buildCreditsCompareRoutePayload,
  buildCreditsPricingRoutePayload,
  buildCreditsStatsRoutePayload,
  buildCreditsWalletsRoutePayload,
  resolveCreditsRoute
} from 'p2p-hiverelay/core/relay-node/api-credits.js'
import { PricingEngine } from 'p2p-hiverelay/incentive/credits/pricing.js'
import { CreditManager } from 'p2p-hiverelay/incentive/credits/index.js'

test('api credits: route helper maps exact GET routes', (t) => {
  t.alike(resolveCreditsRoute('GET', '/api/v1/credits/pricing'), { kind: 'credits-pricing' })
  t.alike(resolveCreditsRoute('GET', '/api/v1/credits/pricing/compare'), { kind: 'credits-pricing-compare' })
  t.alike(resolveCreditsRoute('GET', '/api/v1/credits/stats'), { kind: 'credits-stats' })
  t.alike(resolveCreditsRoute('GET', '/api/v1/credits/wallets'), { kind: 'credits-wallets' })

  t.is(resolveCreditsRoute('POST', '/api/v1/credits/pricing'), null)
  t.is(resolveCreditsRoute('GET', '/api/v1/credits/unknown'), null)
  t.is(resolveCreditsRoute('GET', '/api/credits/pricing'), null)
})

test('api credits: pricing returns rate card', (t) => {
  const node = { pricingEngine: new PricingEngine() }
  const result = buildCreditsPricingRoutePayload({
    route: { kind: 'credits-pricing' },
    node
  })

  t.is(result.ok, true)
  t.is(result.status, 200)
  t.ok(result.payload['ai.infer'])
  t.is(result.payload['ai.infer'].effectiveMargin, 1)
})

test('api credits: pricing falls back to default engine', (t) => {
  const node = {}
  const result = buildCreditsPricingRoutePayload({
    route: { kind: 'credits-pricing' },
    node
  })

  t.is(result.ok, true)
  t.ok(result.payload['ai.infer'])
  t.ok(node._defaultPricingEngine)
})

test('api credits: comparison returns cloud comparison', (t) => {
  const node = { pricingEngine: new PricingEngine({ margin: 1.5 }) }
  const result = buildCreditsCompareRoutePayload({
    route: { kind: 'credits-pricing-compare' },
    node
  })

  t.is(result.ok, true)
  t.ok(result.payload.services)
  t.ok(result.payload.services['ai.infer'])
  t.ok(result.payload.btcPriceUsd > 0)
})

test('api credits: stats returns aggregate wrapped in credits object', (t) => {
  const manager = new CreditManager()
  manager.getOrCreateWallet('a'.repeat(64))
  manager.topUp('a'.repeat(64), 1000)

  const result = buildCreditsStatsRoutePayload({
    route: { kind: 'credits-stats' },
    node: { creditManager: manager }
  })

  t.is(result.ok, true)
  t.is(result.payload.credits.totalWallets, 1)
  t.is(result.payload.credits.totalDeposited, 1000)
})

test('api credits: stats returns zeros when no manager', (t) => {
  const result = buildCreditsStatsRoutePayload({
    route: { kind: 'credits-stats' },
    node: {}
  })

  t.is(result.ok, true)
  t.is(result.payload.credits.totalWallets, 0)
  t.is(result.payload.credits.totalBalance, 0)
})

test('api credits: wallets returns sanitized wallet list', (t) => {
  const manager = new CreditManager()
  manager.getOrCreateWallet('a'.repeat(64))

  const result = buildCreditsWalletsRoutePayload({
    route: { kind: 'credits-wallets' },
    node: { creditManager: manager }
  })

  t.is(result.ok, true)
  t.is(result.payload.wallets.length, 1)
  t.is(result.payload.wallets[0].appPubkey, 'a'.repeat(64))
  t.is(result.payload.wallets[0].tier, 'free')
})

test('api credits: wallets returns empty array when no manager', (t) => {
  const result = buildCreditsWalletsRoutePayload({
    route: { kind: 'credits-wallets' },
    node: {}
  })

  t.is(result.ok, true)
  t.alike(result.payload.wallets, [])
})

test('api credits: unknown route returns 404', (t) => {
  const result = buildCreditsPricingRoutePayload({
    route: { kind: 'unknown' },
    node: {}
  })

  t.is(result.ok, false)
  t.is(result.status, 404)
})
