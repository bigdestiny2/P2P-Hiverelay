import { PricingEngine } from '../../incentive/credits/pricing.js'
import { CreditManager } from '../../incentive/credits/index.js'

const CREDITS_ROUTES = Object.freeze({
  'GET /api/v1/credits/pricing': Object.freeze({ kind: 'credits-pricing' }),
  'GET /api/v1/credits/pricing/compare': Object.freeze({ kind: 'credits-pricing-compare' }),
  'GET /api/v1/credits/stats': Object.freeze({ kind: 'credits-stats' }),
  'GET /api/v1/credits/wallets': Object.freeze({ kind: 'credits-wallets' })
})

function getPricingEngine (node) {
  if (node.pricingEngine) return node.pricingEngine
  if (!node._defaultPricingEngine) {
    node._defaultPricingEngine = new PricingEngine()
  }
  return node._defaultPricingEngine
}

function getCreditManager (node) {
  if (node.creditManager) return node.creditManager
  if (!node._defaultCreditManager) {
    node._defaultCreditManager = new CreditManager()
  }
  return node._defaultCreditManager
}

export function resolveCreditsRoute (method, path) {
  const route = CREDITS_ROUTES[`${method} ${path}`]
  if (!route) return null
  return { ...route }
}

function notFound (route) {
  return {
    ok: false,
    status: 404,
    payload: { error: 'unknown credits route', route: route && route.kind }
  }
}

export function buildCreditsPricingRoutePayload ({ route, node } = {}) {
  if (!route || route.kind !== 'credits-pricing') return notFound(route)
  const engine = getPricingEngine(node)
  return {
    ok: true,
    status: 200,
    payload: engine.getRateCard()
  }
}

export function buildCreditsCompareRoutePayload ({ route, node } = {}) {
  if (!route || route.kind !== 'credits-pricing-compare') return notFound(route)
  const engine = getPricingEngine(node)
  return {
    ok: true,
    status: 200,
    payload: engine.getComparison()
  }
}

export function buildCreditsStatsRoutePayload ({ route, node } = {}) {
  if (!route || route.kind !== 'credits-stats') return notFound(route)
  const manager = getCreditManager(node)
  const stats = manager && typeof manager.stats === 'function'
    ? manager.stats()
    : {
        totalWallets: 0,
        totalBalance: 0,
        totalDeposited: 0,
        totalSpent: 0,
        avgBalance: 0,
        activeWallets7d: 0,
        activeWallets30d: 0
      }
  return {
    ok: true,
    status: 200,
    payload: { credits: stats }
  }
}

export function buildCreditsWalletsRoutePayload ({ route, node } = {}) {
  if (!route || route.kind !== 'credits-wallets') return notFound(route)
  const manager = getCreditManager(node)
  const wallets = manager && typeof manager.wallets === 'object'
    ? Array.from(manager.wallets.values()).map(w => ({
      appPubkey: w.appPubkey || null,
      balance: w.balance || 0,
      totalDeposited: w.totalDeposited || 0,
      totalSpent: w.totalSpent || 0,
      totalBonusReceived: w.totalBonusReceived || 0,
      welcomeCreditsReceived: w.welcomeCreditsReceived || 0,
      tier: w.tier || 'free',
      lastActivity: w.lastActivity || null,
      createdAt: w.createdAt || null
    }))
    : []
  return {
    ok: true,
    status: 200,
    payload: { wallets }
  }
}
